import React from "react";
import Header from "../components/Header";

const InterviewQuest = () => {
  return (
    <>
      <Header />
    </>
  );
};

export default InterviewQuest;
